import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { CreditCard, Check } from 'lucide-react';

const PLANS = [
  {
    id: 'monthly',
    name: 'Monthly Plan',
    price: 49.95,
    period: 'month',
    billing: 'Invoiced every month',
    description: 'Best for short-term usage'
  },
  {
    id: 'quarterly',
    name: 'Quarterly Plan',
    price: 29.95,
    totalPrice: 89.85,
    period: 'month',
    billing: 'Invoiced each quarter ($89.85)',
    description: 'Best for medium-term users',
    savings: '40% savings'
  },
  {
    id: 'annually',
    name: 'Annually Plan',
    price: 19.95,
    totalPrice: 239.40,
    period: 'month',
    billing: 'Invoiced every year ($239.40)',
    description: 'Best for long-term users',
    popular: true,
    savings: '60% savings'
  }
];

const FEATURES = [
  'Unlimited dynamic QR codes',
  'Access to all QR types',
  'Unlimited modifications',
  'Unlimited scans',
  'Multiple download formats',
  'Premium customer support',
  'Cancel anytime'
];

export function BillingPage() {
  const { user } = useAuth();
  const [subscription, setSubscription] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSubscription();
  }, [user]);

  async function loadSubscription() {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .maybeSingle();

      if (error) throw error;
      setSubscription(data);
    } catch (error) {
      console.error('Error loading subscription:', error);
    } finally {
      setLoading(false);
    }
  }

  function getDaysRemaining() {
    if (!subscription?.trial_end_date) return 0;
    const trialEnd = new Date(subscription.trial_end_date);
    const now = new Date();
    const diff = trialEnd.getTime() - now.getTime();
    return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-6 py-12">
        <div className="max-w-6xl mx-auto">
          <Link to="/dashboard" className="text-purple-600 hover:text-purple-700 mb-4 inline-block">
            ← Back to Dashboard
          </Link>
          <h1 className="text-3xl font-bold text-gray-800 mb-8">Billing & Subscription</h1>

          {subscription?.status === 'trial' && (
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-6 mb-8">
              <h2 className="text-xl font-semibold text-purple-900 mb-2">Trial Period</h2>
              <p className="text-purple-700">
                You have {getDaysRemaining()} days remaining in your free trial. Upgrade now to continue enjoying all features.
              </p>
            </div>
          )}

          <div className="grid md:grid-cols-3 gap-6">
            {PLANS.map((plan) => (
              <div
                key={plan.id}
                className={`bg-white rounded-xl shadow-lg overflow-hidden ${
                  plan.popular ? 'ring-2 ring-purple-600' : ''
                }`}
              >
                {plan.popular && (
                  <div className="bg-purple-600 text-white text-center py-2 text-sm font-semibold">
                    Most Popular
                  </div>
                )}
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">{plan.name}</h3>
                  <div className="mb-4">
                    <span className="text-4xl font-bold text-gray-800">${plan.price}</span>
                    <span className="text-gray-600">/{plan.period}</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{plan.billing}</p>
                  <p className="text-sm text-purple-600 font-semibold mb-4">{plan.description}</p>
                  {plan.savings && (
                    <div className="bg-green-50 text-green-700 px-3 py-1 rounded-full text-sm font-medium inline-block mb-4">
                      {plan.savings}
                    </div>
                  )}

                  <button
                    className={`w-full py-3 rounded-lg font-semibold transition ${
                      plan.popular
                        ? 'bg-purple-600 hover:bg-purple-700 text-white'
                        : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                    }`}
                  >
                    {subscription?.plan_type === plan.id && subscription?.status === 'active'
                      ? 'Current Plan'
                      : 'Select Plan'}
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8 mt-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">All Plans Include</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {FEATURES.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8 mt-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Payment Methods</h2>
            <div className="space-y-4">
              <button className="w-full flex items-center justify-center space-x-3 border-2 border-gray-300 rounded-lg p-4 hover:border-purple-600 transition">
                <CreditCard className="w-6 h-6" />
                <span className="font-medium">Add Credit/Debit Card</span>
              </button>
              <button className="w-full flex items-center justify-center space-x-3 border-2 border-gray-300 rounded-lg p-4 hover:border-purple-600 transition">
                <svg className="w-6 h-6" viewBox="0 0 24 24">
                  <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
                </svg>
                <span className="font-medium">Google Pay</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
