import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://yjmfghmcrleysafgrmeb.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlqbWZnaG1jcmxleXNhZmdybWViIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE4NjU3MDgsImV4cCI6MjA3NzQ0MTcwOH0.ZGy7WEaJbNKjZNlyqSeNpUuh56hKoqES21UyHKV-4v8";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
